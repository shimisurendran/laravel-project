@extends('layouts.layout')
@section('content')





<div class="container py-5" style="text-align:center">

<div class="row">

<div class="col-md-12">
<!-- <div id="update_success_message"></div> -->

<!-- <div id="success_message"></div> -->


<table class="table" id="table_body">
  <thead>
 <tr>
	<th colspan="5" ><h4 >Manage <b>Users</b></h4>

</th>
	<th colspan="3"><a href="#addModal" class="" data-toggle="modal" > 
		<span style="background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New User</span>
	</a>
	</th></tr>  
    <tr>
      <th scope="col">Serial No</th>
      <th scope="col">NAME</th>
      <th scope="col">EMAIL ID</th>
      <th scope="col">USER ROLE</th>
	  <th scope="col">ADDRESS</th>
	  <th scope="col">PHONE NUMBER</th>
	  <!-- <th scope="col">IMAGE</th> -->
      <th scope="col" colspan="2">ACTIONS</th>
    </tr>
  </thead>
  <tbody>
 
  </tbody>
</table>

</div>
<!-- </div> -->
<!-- </div> -->
</div></div>

<!-- Add Modal HTML -->
<div id="addModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div id="success_message"></div>
			<!-- <form id="adduser" class="adduser">
      -->
	  @csrf
				<div class="modal-header">						
					<h4 class="modal-title">Add New User</h4>
					
					<button type="button" class="close" id="closeBtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">	
					
				
					<div class="form-group">
						
						<label>Name</label>
						<input type="text" class="form-control" name="name" id="name">
						<!-- <ul id="saveform_errlistname"></ul> -->

						<span class="text-danger error-text name_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="email" id="email">
						<span class="text-danger error-text email_error" style="position:fixed"></span>
					</div>

					<div class="form-group">
						<label>User Role</label>
						<div class="form-group">
                            <select   class="form-control"name="role" id="role">
                            <option value="">-- Select a Role --</option>
                          
                            <option >
                              Admin
                            </option>
                            <option >
                              Vendor
                            </option>
                            <option >
                              Editor
                            </option>
                           
                        </select>
						<span class="text-danger error-text role_error" style="position:fixed"></span>
					</div>
					

					<div class="form-group">
					<label>Password</label>
                                <input type="password" class="form-control" name="password" autocomplete="new-password" id="password">

								<span class="text-danger error-text password_error" style="position:fixed"></span>
                            </div>
                      

                            <div class="form-group">
							<label>Confirm Password</label>
                                <input  type="password" id="password1"  class="form-control" name="password_confirmation" autocomplete="new-password" >
								<span class="text-danger error-text password_error" style="position:fixed"></span>
                            </div>
							
					<div class="form-group">
						<label>Address</label>
						<textarea class="form-control" name="address" id="address"></textarea>
						<span class="text-danger error-text address_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Phone</label>
						<input type="text" class="form-control"name="phone" id="phone">
						<span class="text-danger error-text phone_error" style="position:fixed"></span>
					</div>
					
					<!-- <div class="form-group">
						<label>Image</label>
						<input type="file" class="form-control"name="image" id="image">
					</div> -->
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel"> -->
					<!-- <input type="button" class="" value="Cancel" style="color:black;background-color:grey;"> -->
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" style="color:#4154f1"> -->
					<button type="button" class="btn btn-default " id="cancel-add"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success add-user" >save</button>
					
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>

</div></div></div>
<!-- Edit Modal HTML -->
<div id="editModal" class="modal fade">
	<div class="modal-dialog">

		<div class="modal-content">
	
			<!-- <form id="updateUser"> -->
			
				<input type="hidden" id="user_id" name="user_id" >
				<div class="modal-header">						
					<h4 class="modal-title">Edit User Details</h4>
					<button type="button" class="close" id="closebtn1">&times;</button>
				</div>
				<div class="modal-body">	
					

				<div class="form-group">
						<label>Name</label>
						<input type="text" class="form-control" name="username" id="username">

						<span class="text-danger error-text username_error" style="position:fixed"></span>
					</div>
				<div class="form-group">
						<label>Email Id</label>
						<input type="text" class="form-control" readonly name="email1" id="email1">
						
					</div>
					
					<div class="form-group">
						<label>Address</label>
						<textarea name="user_address" id="user_address" class="form-control"></textarea>
						<span class="text-danger error-text user_address_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" class="form-control"name="phoneNumber" id="phoneNumber">
						<span class="text-danger error-text phoneNumber_error" style="position:fixed"></span>
					</div>
					<!-- <div class="form-group">
						<label>Image</label> -->
						<!-- <input type="file" class="form-control" required name="image" id="image"> -->


						<!-- <input type="file" name="avatar" class="form-control" id="avatar">
				
					</div>		 -->
					<div class="form-group" id="avatar"></div>			
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-edit">
					<input type="submit" class="btn btn-info updateuser" value="Update"> -->
					<button type="button" class="btn btn-default " id="cancel-edit"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success updateuser" value="Update" >save</button>
					
				</div>
			<!-- </formsss> -->
		</div>
	</div>
</div>
<!-- Delete Modal HTML -->
<div id="deleteModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="{{url('delete-user')}}" method="post" id="deleteUser">
				@csrf
				@method('DELETE')
				<div class="modal-header">						
					<h4 class="modal-title">Delete Employee</h4>

					<input type="hidden" id="userid" name="userid">
					<button type="button" class="close" id="closebtn2" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<p>Are you sure you want to delete  Records?</p>
					<p class="text-warning"><small>This action cannot be undone.</small></p>
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-delete">
					<input type="submit" class="btn btn-danger" value="Delete"> -->
					<button type="button" class="btn btn-default " id="cancel-delete"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="submit" class="btn btn-danger"  >Delete</button>
					
				</div>
			</form>
		</div>
	</div>
</div>






@endsection
@section('scripts')
<script>
$(document).ready(function(){
   $(document).on('click','.edit',function(){
      var user_id=$(this).val();
	//   alert(user_id);
	$('#editModal').modal('show');

	$.ajax({
		type:"GET",
		url:"/edit-user/"+user_id,
		
		success:function(response){
			console.log(response.user.image);
			$('#email1').val(response.user.email);
			$('#username').val(response.user.name);
			$('#user_address').val(response.user.address);
			$('#phoneNumber').val(response.user.phone);
			$('#avatar').val(response.user.image);
			// $("#avatar").html(
            //   `<img src="${response.user.image}" width="100" class="img-fluid img-thumbnail">`);
			$('#user_id').val(user_id);

		}
	});
   });


   $('#closebtn1').click(function() {
    $('#editModal').modal('hide');
	// $('#editModal').find('input').val("");
	$(document).find('span.error-text').text('');
});
// btn btn-default
$('#cancel-edit').click(function() {

    $('#editModal').modal('hide');
	$('#editModal').find('input').val("");
});
});



$(document).ready(function(){
	

	$('#addModal').find('input').val("");


	$(document).on('click','.delete',function(){
		var user_id=$(this).val();
		$('#deleteModal').modal('show');
		$('#userid').val(user_id);
		// alert(user_id);
		


	});
	// cancel-delete
	$('#cancel-delete').click(function() {
    $('#deleteModal').modal('hide');
});
	$('#closebtn2').click(function() {
    $('#deleteModal').modal('hide');
	$('#deleteModal').find('input').val("");
});


});
$(document).ready(function(){



$(document).on('click', '.updateuser', function(e) {
       e.preventDefault();
	//    alert($('#user_id').val());
	
	   var data={
			'username':$('#username').val(),
			'user_address':$('#user_address').val(),
			'phoneNumber':$('#phoneNumber').val(),
			'user_id':$('#user_id').val()
			// 'image':$('#image').val(),
		}

		$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
	$.ajax({
			type:"POST",
			url:"/update-user",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			

			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					// console.log(err_values);
					
				})
			}
			else{
				// $('#addUser')[0].reset();
				// alert(response.user);
				
				$('#update_success_message').html("");
				$('#update_success_message').addClass('alert alert-success');

				$('#update_success_message').text(response.message);
				fetchUser();
				$('#editModal').modal('hide');
				$('#editModal').find('input').val("");

				
				// $('#editModal').find('input').val("");
				
				
			}
			
			}
		});

});
// });
// $(document).ready(function(){

fetchUser();

	function fetchUser()
	{
		$.ajax({
			type:"GET",
			url:"fetch-user",
			dataType:"json",
			success:function(response){
				// console.log(response.users);
				$('tbody').html("");
				$.each(response.users,function(key,item){
				$('tbody').append('<tr>\
				<td>'+item.id+'</td>\
				<td>'+item.name+'</td>\
				<td>'+item.email+'</td>\
				<td>'+item.role+'</td>\
				<td>'+item.address+'</td>\
				<td>'+item.phone+'</td>\
				<td> <button type="button" data-toggle="modal" class="edit" value="'+item.id+'" style="border:none; color:orange;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button></td>\
				<td> <button type="button" data-toggle="modal" class="delete" value="'+item.id+'" style="border:none; color:red;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></button></td>\
				</tr>');
				});

			}
		});
	}
	
	$(document).on('click','.add-user',function(e){
		e.preventDefault();
		
		
		// console.log($('#image').val());
		var data={
			
			'name':$('#name').val(),
			'email':$('#email').val(),
			'role':$('#role').val(),
			'password':$('#password').val(),
			'password_confirmation':$('#password1').val(),
			'address':$('#address').val(),
			'phone':$('#phone').val(),
			// 'image':$('#image').val(),
			
		}
		$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$.ajax({
			type:"POST",
			url:"/add_user",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			

			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					
				})
			}
			else{
				// $('#addUser')[0].reset();
				// alert(response.user);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchUser();
				$('#addModal').modal('hide');

				
				$('#addModal').find('input').val("");
				
				
			}
			
			}
		});
		

		
	});


	
   $('#closeBtn').click(function() {
	$(document).find('span.error-text').text('');
	$('#addModal').find('input').val("");
	$('#address').val("");

    $('#addModal').modal('hide');
	
	
});

$('#cancel-add').click(function() {
	$(document).find('span.error-text').text('');
	$('#addModal').find('input').val("");
	$('#address').val("");
	$('#addModal').modal('hide');
	
});

});

   </script>

@endsection