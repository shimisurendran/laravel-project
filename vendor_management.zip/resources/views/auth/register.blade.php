
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="assets/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/assets/css/style.css" rel="stylesheet">

    <title>The Knowledge Academy</title>
  </head>
  <body>

<div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="_lk_de">
              <div class="form-03-main">
                <div class="logo">
                  <img src="assets/img/tka1.png">
                
                </div>
                
                    <form method="POST" action="{{ route('register') }}">
                        @csrf

                        <!-- <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label> -->

                            <div class="form-group">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus placeholder="Enter Name">

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        <!-- </div> -->

                        <!-- <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label> -->

                              <div class="form-group">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="Enter Email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        <!-- </div> -->

                        <!-- <div class="row mb-3">
                            <label for="role" class="col-md-4 col-form-label text-md-end">{{ __('role') }}</label> -->
                            <!-- <div class="form-group">
                                <input id="role" type="text" class="form-control @error('password') is-invalid @enderror" name="role" required autocomplete="role" placeholder="enter role">

                               
                            </div> -->




                            <div class="form-group">
                            <select   class="form-control " required name="role" id="role">
                            <option >-- Select a Role --</option>
                          
                            <option>
                              Admin
                            </option>
                            <option>
                              Vendor
                            </option>
                            <option>
                              Editor
                            </option>
                            @error('role')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                        </select>
</div>
                            
                        <!-- </div> -->


                        <!-- <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label> -->

                            <div class="form-group">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password" placeholder="enter Password ">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                      

                            <div class="form-group">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm password">
                            </div>
                        <!-- </div> -->

                        <div class="form-group">
                  <div class="_btn_04">
                                <button type="submit" class="_btn_04" style="border: none;">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){
    $('#role').on('change', function () {
                var role = this.value;
	  alert(role);
      console.log(role);
	// $('#editModal').modal('show');

	// $.ajax({
	// 	type:"GET",
	// 	url:"/edit-user/"+user_id,
		
	// 	success:function(response){
	// 		console.log(response.user.name);
	// 		$('#email').val(response.user.email);
	// 		$('#name').val(response.user.name);
	// 		$('#address').val(response.user.address);
	// 		$('#phone').val(response.user.phone);
	// 		$('#user_id').val(user_id);

	// 	}
	// });
   });



  
});
</body>
</html>