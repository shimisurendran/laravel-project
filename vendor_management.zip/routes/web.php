<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

Auth::routes();

// Route::middleware(['auth', 'user-access:admin'])->group(function () {

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::view('create','Admin/create_user');
Route::get('/getUsers', [UserController::class, 'getUsers']);

Route::get('/fetch-user', [UserController::class, 'fetchUser']);

Route::post('/getUserbyid', [UserController::class, 'getUserbyid']);

Route::post('/add_user', [UserController::class, 'addUser']);


Route::get('edit-user/{id}', [UserController::class, 'edit']);

Route::post('update-user', [UserController::class, 'update']);
Route::delete('delete-user', [UserController::class, 'delete']);


// Route::view('/getUsers','view_all_user');update-user

Route::get('/getBranch', [UserController::class, 'getBranch']);
Route::get('/fetch-branch', [UserController::class, 'fetchBranch']);
Route::get('fetch_country', [UserController::class, 'fetch_country']);
Route::post('api/fetch-states/{idCountry}', [UserController::class, 'fetchState']);
Route::post('api/fetch-cities/{idState}', [UserController::class, 'fetchCity']);

Route::post('/add_branch', [UserController::class, 'addBranch']);

Route::get('edit-branch/{branch_id}', [UserController::class, 'editBranch']);

Route::get('update-branch', [UserController::class, 'updateBranch']);
Route::delete('delete-branch', [UserController::class, 'deleteBranch']);


//catrgory

Route::get('/getCategory', [UserController::class, 'getCategory']);
Route::get('/fetch-category', [UserController::class, 'fetchCategory']);
Route::post('/add_category', [UserController::class, 'addCategory']);
Route::get('edit-category/{cid}', [UserController::class, 'editCategory']);
Route::post('update-category', [UserController::class, 'updateCategory']);
Route::delete('delete-category', [UserController::class, 'deleteCategory']);

//Vendor

Route::get('/getVendor', [UserController::class, 'getVendor']);
// });

Route::get('send-mail', [UserController::class, 'sendMail']);

// Route::middleware(['auth', 'user-access:vendor'])->group(function () {
  
//     return view('vendorHome');
// });

Route::post('/addvendor', [UserController::class, 'addVendor']);

// Route::match(['get', 'post'], '/add_vendor', [UserController::class, 'addVendor']);
Route::get('/fetch-vendor', [UserController::class, 'fetchVendor']);
Route::get('edit-vendor/{vendor_id}', [UserController::class, 'editVendor']);

Route::post('update-vendor', [UserController::class, 'updateVendor']);
Route::delete('delete-vendor', [UserController::class, 'deleteVendor']);