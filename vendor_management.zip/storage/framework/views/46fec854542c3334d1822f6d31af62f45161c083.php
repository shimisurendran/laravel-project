
<?php $__env->startSection('content'); ?>



<div class="container py-5" style="text-align:center">

<div class="row">

<div class="col-md-12">

<!-- <div id="success_message"></div> -->

   
<!-- <div class="card" > -->



            <!-- <div class="card-body"> -->

<table class="table" >
  <thead>
 <tr>
	<th colspan="7"><h4 >Manage <b>Branches</b></h4>

</th>
	<th colspan="3">
       <a href="#addModal" class="" data-toggle="modal" > <span style="background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New Branch</span></a> 
    
    <!-- <button type="button" data-toggle="modal" class="addbranch" value="" style="border:none; background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New Branch</button> -->
					
</th></tr>  
    <tr>
      <th scope="col">Serial No</th>
      <th scope="col">BRANCH NAME</th>
      <th scope="col">EMAIL ADDRESS</th>
      <th scope="col">PHONE NUMBER</th>
	  <th scope="col">ADDRESS</th>
	  <th scope="col">COUNTRY</th>
      <th scope="col">STATE</th>
      <th scope="col">CITY</th>
	  <!-- <th scope="col">IMAGE</th> -->
      <th scope="col" colspan="3">ACTIONS</th>
    </tr>
  </thead>
  <tbody>
  
    
  </tbody>
</table>

</div>
<!-- </div> -->
<!-- </div> -->
</div></div>

<!-- Add Modal HTML -->
<div id="addModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<!-- <form action="<?php echo e(url('add_branch')); ?>" method="post"  enctype="multipart/form-data" id="adduser"> -->
			<!-- <form action="" method="post"  enctype="multipart/form-data" id="addbranch"> -->
            <?php echo csrf_field(); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Add New Branch</h4>
					<button type="button" class="close" id="closeBtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<div class="form-group">
						<label>Branch Name</label>
						<input type="text" class="form-control"  name="name" id="name">
						<span class="text-danger error-text name_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Branch Email</label>
						<input type="text" class="form-control" name="email" id="email">
						<span class="text-danger error-text email_error" style="position:fixed"></span>
					</div>

                    <div class="form-group">
						<label>Phone Number</label>
						<input type="text" class="form-control" name="phone" id="phone">
						<span class="text-danger error-text phone_error" style="position:fixed"></span>
					</div>
                    <div class="form-group">
						<label>Address</label>
						<textarea class="form-control" required name="address" id="address"></textarea>
						<span class="text-danger error-text address_error" style="position:fixed"></span>
					</div>

					<div class="form-group">
						<label>Country</label>
						<div class="form-group">
                            <select   class="form-control " required name="country" id="country">
                                <option value="">--Select Country--</option>
                            <?php $__currentLoopData = $data['countries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>">
                                <?php echo e($data->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                        </select>
						<span class="text-danger error-text country_error" style="position:fixed"></span>
					</div>
					

                    <div class="form-group">
						<label>State</label>
						<div class="form-group">
                            <select class="form-control " required name="state" id="state">
                           
							
                        </select>
						<span class="text-danger error-text state_error" style="position:fixed"></span>
					</div>


                    <div class="form-group">
						<label>City</label>
						<div class="form-group">
                            <select   class="form-control " required name="city" id="city">
                        
                         
                        </select>
						 
						<span class="text-danger error-text city_error" style="position:fixed"></span>
					</div>
	<!-- <input type="text" id="b_city" name="b_city"> -->
					
					
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-add">
					<input type="submit" class="btn btn-success" value="Add"> -->
					<button type="button" class="btn btn-default " id="cancel-add"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success add-branch" >save</button>
					
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>

</div></div></div>
<!-- Edit Modal HTML -->
<div id="editModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<!-- <form id="updateUser" action="<?php echo e(url('update-branch')); ?>" method="post"  enctype="multipart/form-data"> -->
				
				<input type="hidden" id="branch_id" name="branch_id" >
				<div class="modal-header">						
					<h4 class="modal-title">Edit Branch Details</h4>
					<button type="button" class="close" id="closebtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">	
					

				<div class="form-group">
						<label>Branch Name</label>
						<input type="text" class="form-control" name="branch_name" id="branch_name" readonly>

					</div>
				<div class="form-group">
						<label>Branch Email</label>
						<input type="text" class="form-control" name="branch_email" id="branch_email">
						
					</div>
					
					<div class="form-group">
						<label>Branch Address</label>
						<textarea name="branch_address" id="branch_address" class="form-control" required></textarea>
						<span class="text-danger error-text branch_address_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Phone Number</label>
						<input type="text" class="form-control" name="phoneNumber" id="phoneNumber">
						<span class="text-danger error-text phoneNumber_error" style="position:fixed"></span>
					</div>


					<!-- <div class="form-group">
					<label>Country</label>
                            <select   class="form-control " required name="coun" id="coun">
						
                        </select>
						<span class="text-danger error-text coun_error" style="position:fixed"></span>
					</div>

					<div class="form-group">
					<label>State</label>
                            <select   class="form-control " required name="stat" id="stat">
							
                        </select>
						<span class="text-danger error-text stat_error" style="position:fixed"></span>
					</div>

					<div class="form-group">
					<label>City</label>
                            <select   class="form-control " required name="cit" id="cit">
						
                        </select>
						<span class="text-danger error-text cit_error" style="position:fixed"></span>
					</div>
 -->




				
				
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-edit">
					<input type="submit" class="btn btn-info" value="Update"> -->
					<button type="button" class="btn btn-default " id="cancel-edit"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success update-branch" >Update</button>
					
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>
<!-- Delete Modal HTML -->
<div id="deleteModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="<?php echo e(url('delete-branch')); ?>" method="post" id="deleteUser">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Delete Branch</h4>

					<input type="hidden" id="branchid" name="branchid">
					<button type="button" class="close" id="closebtnedit" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<p>Are you sure you want to delete  Records?</p>
					<p class="text-warning"><small>This action cannot be undone.</small></p>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-delete">
					<input type="submit" class="btn btn-danger" value="Delete">
				</div>
			</form>
		</div>
	</div>
</div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>




$(document).ready(function(){


	fetchBranch();

function fetchBranch()
{
	$.ajax({
		type:"GET",
		url:"fetch-branch",
		dataType:"json",
		success:function(response){
			// console.log(response.users);
			$('tbody').html("");
			$.each(response.branches,function(key,item){
			$('tbody').append('<tr>\
			<td>'+item.id+'</td>\
			<td>'+item.b_name+'</td>\
			<td>'+item.b_email+'</td>\
			<td>'+item.b_phone+'</td>\
			<td>'+item.b_address+'</td>\
			<td>'+item.b_country+'</td>\
			<td>'+item.b_state+'</td>\
			<td>'+item.b_city+'</td>\
			<td> <button type="button" data-toggle="modal" class="edit" value="'+item.id+'" style="border:none; color:orange;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button></td>\
			<td> <button type="button" data-toggle="modal" class="delete" value="'+item.id+'" style="border:none; color:red;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></button></td>\
			</tr>');
			});

		}
	});
}


	$('#cancel-add').click(function() {
    $('#addModal').modal('hide');
});



	$(document).on('click','.edit',function(){
      var branch_id=$(this).val();
    //   alert(branch_id);
	$('#editModal').modal('show');
	$("#coun").html('');
	$("#stat").html('');
	$("#cit").html('');

	$.ajax({
		type:"GET",
		url:"/edit-branch/"+branch_id,
		
		success:function(response){
            // alert(response.status);
			// console.log(response.data.countries);
			 $('#branch_email').val(response.branch.b_email);
			$('#branch_name').val(response.branch.b_name);
			 $('#branch_address').val(response.branch.b_address);
			$('#phoneNumber').val(response.branch.b_phone);
            $('#coun').val(response.branch.b_country);
            $('#stat').val(response.branch.b_state);
            $('#cit').val(response.branch.b_city);
			// $('#city').val(response.branch.b_city);
			// $("#avatar").html(
            //   `<img src="/images/${response.user.image}" width="100" class="img-fluid img-thumbnail">`);


			
			// $('#cit').html('<option>-- Select city --</option>');
			$("#coun").html('<option>' + response.branch.b_country + '</option>');
			$("#stat").html('<option>' + response.branch.b_state + '</option>');
			$("#cit").html('<option>' + response.branch.b_city + '</option>');
			$.each(response.data.countries, function (key, value) {
                            $("#coun").append('<option value="' + value.id + '">' + value.name + '</option>');
                        });


			$('#branch_id').val(branch_id);

		}
	});


	$('#coun').on('change', function() {
    
	var idCountry = this.value;
	

	$("#stat").html('');
	$.ajax({
		type: "POST",
	  
		url:"/api/fetch-states/"+idCountry,
	  
		data: {
		  
			_token: '<?php echo e(csrf_token()); ?>'
		},
		dataType: 'json',
		success: function (result) {
	  
			$('#stat').html('<option value="">-- Select State --</option>');
			$.each(result.states, function (key, value) {
				$("#stat").append('<option value="' + value
					.id + '">' + value.name + '</option>');
			});
			// $('#cit').html('<option value="">-- Select City --</option>');
		}
	});

});


$('#stat').on('change', function () {
              
			  var idState = this.value;
			  $("#cit").html('');
			  $.ajax({
				  url:"/api/fetch-cities/"+idState,
				  type: "POST",
				  data: {
					  _token: '<?php echo e(csrf_token()); ?>'
				  },
				  success: function (res) {
					  $('#cit').html('<option value="">-- Select City --</option>');
					  $.each(res.cities, function (key, value) {
						  $("#cit").append('<option value="' + value
							  .id + '">' + value.name + '</option>');
						  //   $('#b_city').val();
					  });
				  }
			  });
		  });

		 




});

$('#cancel-edit').click(function() {
    $('#editModal').modal('hide');
});


$('#closebtn').click(function() {
    $('#editModal').modal('hide');
});
//    });

 
  

  




// $(document).ready(function(){
	$(document).on('click','.delete',function(){
		var branch_id=$(this).val();
		$('#deleteModal').modal('show');
		$('#branchid').val(branch_id);
	
	});

	
	$('#closebtnedit').click(function() {
    $('#deleteModal').modal('hide');
});

$('#cancel-delete').click(function() {
    $('#deleteModal').modal('hide');
});

// });


// $(document).ready(function(){

	$(document).on('click','.addbranch',function(){

        $('#addModal').modal('show');
	});


       /* Country Dropdown Change Event
            --------------------------------------------
            --------------------------------------------*/
        $('#country').on('change', function() {
   
                var idCountry = this.value;
				console.log(idCountry);
                $("#state").html('');
                $.ajax({
                    type: "POST",
                  
                    url:"/api/fetch-states/"+idCountry,
                  
                    data: {
                      
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function (result) {
                  
                        $('#state').html('<option value="">-- Select State --</option>');
                        $.each(result.states, function (key, value) {
                            $("#state").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                        $('#city').html('<option value="">-- Select City --</option>');
                    }
                });

            });



    /*State Dropdown Change Event
            --------------------------------------------
            --------------------------------------------*/
            $('#state').on('change', function () {
              
                var idState = this.value;
                $("#city").html('');
                $.ajax({
                    url:"/api/fetch-cities/"+idState,
                    type: "POST",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function (res) {
                        $('#city').html('<option value="">-- Select City --</option>');
                        $.each(res.cities, function (key, value) {
                            $("#city").append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                            //   $('#b_city').val();
                        });
                    }
                });
            });
  
    $('#closeBtn').click(function() {
    $('#addModal').modal('hide');
});


$('#cancel-add').click(function() {
    $('#addModal').modal('hide');
});


$(document).on('click','.add-branch',function(e){
		e.preventDefault();
		
		
		console.log($('#branch_name').val());
		var data={
			
			'name':$('#name').val(),
			'email':$('#email').val(),
			'address':$('#address').val(),
			'phone':$('#phone').val(),
			'country':$('#country').val(),
			'state':$('#state').val(),
			'city':$('#city').val(),
			// 'image':$('#image').val(),
			
		}
		$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$.ajax({
			type:"POST",
			url:"/add_branch",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			

			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					
				})
			}
			else{
				// $('#addUser')[0].reset();
				// alert(response.user);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchBranch();
				$('#addModal').modal('hide');

				
				$('#addModal').find('input').val("");
				
				
			}
			
			}
		});
		

		
	});





//update branch

$(document).on('click', '.update-branch', function(e) {
       e.preventDefault();
	// alert($('#branch_id').val());
	
	   var data={
			'branch_name':$('#branch_name').val(),
			'branch_email':$('#branch_email').val(),
			'branch_address':$('#branch_address').val(),
			'phoneNumber':$('#phoneNumber').val(),
			// 'coun':$('#coun').val(),
			// 'stat':$('#stat').val(),
			// 'cit':$('#cit').val(),
			'branch_id':$('#branch_id').val()
			
		}

		$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
	$.ajax({
			type:"GET",
			url:"/update-branch",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			

			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					// console.log(err_values);
					
				})
			}
			else{
				// $('#addUser')[0].reset();
				// alert(response.user);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchBranch();
				$('#editModal').modal('hide');
				$('#editModal').find('input').val("");

				
				// $('#editModal').find('input').val("");
				
				
			}
			
			}
		});

});


});


   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sample\vendor_management\resources\views/admin/view_all_branches.blade.php ENDPATH**/ ?>