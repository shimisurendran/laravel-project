
<?php $__env->startSection('content'); ?>



<div class="container py-5" style="text-align:center">

<div class="row">

<div class="col-md-12">


<!-- <div id="success_message"></div> -->


	

<table class="table" id="table_body">
  <thead>
 <tr>
	<th colspan="9"><h4 >Manage <b>Vendor</b></h4>

</th>
	<th colspan="4"><a href="#addModal" class="" data-toggle="modal" > 
		<span style="background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New Vendor</span>
	</a>
	</th></tr>  
    <tr>
      <th scope="col">Serial No</th>
      <th scope="col">VENDOR NAME</th>
      <th scope="col">EMAIL ID</th>
      <th scope="col">ADDRESS</th>
	  <th scope="col">PINCODE</th>
	  <th scope="col">COUNTRY</th>
      <th scope="col">STATE</th>
      <th scope="col">CITY</th>
      <th scope="col">CONTACTS</th>
      <th scope="col">BILLING ADDRESS</th>
	  <!-- <th scope="col">IMAGE</th> -->
      <th scope="col" colspan="2">ACTIONS</th>
    </tr>
  </thead>
  <tbody id="t_body">
 
  </tbody>
</table>

</div>
<!-- </div> -->
<!-- </div> -->
</div></div>

<!-- Add Modal HTML -->
<div id="addModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div id="success_message"></div>
			<!-- <form id="adduser" class="adduser">
      -->
	  <?php echo csrf_field(); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Add New Vendor</h4>
					
					<button type="button" class="close" id="closeBtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">	
					
				<table>	<tbody id="modal-tbody">
					<tr>
						<td><label>Vendor Name</label></td>
						<td><span class="text-danger error-text name_error" style="position:fixed;text-align:center;padding-top:40px;"></span>
							<select class="form-control" name="name" id="name">
							<option value="">--Select Vendor Name--</option>
							<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<option><?php echo e($vendor->name); ?></option>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					
						
						</select>
					
					</td>
						
					</tr>
					<tr>
						<td><label>Email</label></td>
						<td><input type="text" class="form-control" name="email" id="email">
					
						<span class="text-danger error-text email_error" style="position:fixed"></span>
					</td>
						

					</tr>

					<tr>
						<td><label>Address</label></td>
						<td><textarea class="form-control" name="address" id="address"></textarea>
						<span class="text-danger error-text address_error" style="position:fixed"></span></td>
					</tr>

					<tr>
						<td><label>Pincode</label></td>
						<td><input type="text" class="form-control"name="pincode" id="pincode">
						<span class="text-danger error-text pincode_error" style="position:fixed"></span></td>
					</tr>


					<tr>
						<td><label>Country</label>
						</td>
						<td><span class="text-danger error-text country_error" style="position:fixed;padding-top:40px;" ></span> 
							<select   class="form-control "  name="country" id="country">
                                <option value="">--Select Country--</option>
                            <?php $__currentLoopData = $data['countries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>">
                                <?php echo e($data->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
							    </select>
								</td>

								
					
					</tr>

					<tr>
						<td><label>State</label></td>
						<td>  <select class="form-control " name="state" id="state">
                        </select>
						<span class="text-danger error-text state_error" style="position:fixed" id=""></span>
					</td>
					</tr>

					<tr>
						<td><label>City</label></td>
						<td> <select   class="form-control "name="city" id="city">
                        </select>
						<span class="text-danger error-text city_error" style="position:fixed"></span>
					</td>
					</tr>

					<tr>
						<td><label>Billing Address</label></td>
						<td><textarea class="form-control" name="bill_address" id="bill_address"></textarea>
						<span class="text-danger error-text bill_address_error" style="position:fixed"></span></td>
					</tr>
					
					<tr>
						<td> <label>Phone Number</label></td>
						<td><input type="text" name="phone[]" class="form-control"  id="phone"/>
 </td>
 <td> <button id="addPhoneNumber" class="form-control"style="width:40px;height:40px;text-align:center;background-color:#28a745;;color:white;" ><b>+</b></button>

 <span class="text-danger error-text phone_error" style="position:fixed"></span></td>
</tr>


</tbody>
				</table>
				
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default " id="cancel-add"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success add-vendor" >save</button>
					
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>

</div></div></div>
<!-- Edit Modal HTML -->
<div id="editModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
		<input type="hidden" id="vendor_id" name="vendor_id" >
		
		<div class="modal-header">						
					<h4 class="modal-title">Edit Vendor Details</h4>
					
					<button type="button" class="close" id="closeBtn1" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">	
					
	
			<!-- <form id="updateUser" action="<?php echo e(url('update-user')); ?>" method="post"  enctype="multipart/form-data"> -->
					
			<table>	<tbody id="modal-tbody_edit">
					<tr>
						<td><label>Vendor Name</label></td>
						<td>
							<select class="form-control" name="vendorName" id="vendorName">
							<!-- <option value="">--Select Vendor Name--</option> -->
							<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<option><?php echo e($vendor->name); ?></option>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</select>
						<span class="text-danger error-text vendorName_error" style="position:fixed;text-align:center;padding-top:10px;"></span>
					</td>
						
					</tr>
					<tr>
						<td><label>Email</label></td>
						<td><input type="text" class="form-control" name="vendorEmail" id="vendorEmail">
					
						<span class="text-danger error-text vendorEmail_error" style="position:fixed"></span>
					</td>
						

					</tr>

					<tr>
						<td><label>Address</label></td>
						<td><textarea class="form-control" name="vendorAddress" id="vendorAddress"></textarea>
						<span class="text-danger error-text vendorAddress_error" style="position:fixed"></span></td>
					</tr>

					<tr>
						<td><label>Pincode</label></td>
						<td><input type="text" class="form-control"name="vendorPincode" id="vendorPincode">
						<span class="text-danger error-text vendorPincode_error" style="position:fixed"></span></td>
					</tr>


					
					<tr>
						<td><label>Country</label></td>
						<td>  <select class="form-control"name="vendorCountry" id="vendorCountry">
                        </select>
						<span class="text-danger error-text vendorCountry_error" style="position:fixed" ></span>
					</td>
					</tr>

					<tr>
						<td><label>State</label></td>
						<td>  <select class="form-control"name="vendorState" id="vendorState">
                        </select>
						<span class="text-danger error-text vendorState_error" style="position:fixed" ></span>
					</td>
					</tr>

					<tr>
						<td><label>City</label></td>
						<td> <select   class="form-control "  name="city" id="vendorCity">
                        </select>
						<span class="text-danger error-text vendorCity_error" style="position:fixed"></span>
					</td>
					</tr>

					<tr>
						<td><label>Billing Address</label></td>
						<td><textarea class="form-control" name="billAddress" id="billAddress"></textarea>
						<span class="text-danger error-text billAddress_error" style="position:fixed"></span></td>
					</tr>
					
					<tr>
						<!-- <td> <label>Phone Number</label></td>
						<td><input type="text" name="vendorPhone[]" class="form-control"  id="vendorPhone"/>
 </td>
 <td> <button id="addPhone" class="form-control"style="width:40px;height:40px;text-align:center;background-color:#28a745;;color:white;" ><b>+</b></button>-->

 <span class="text-danger error-text phone_error" style="position:fixed"></span></td> 
</tr>
<div id="edit_tr"></div>

</tbody>
				</table>
			
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-edit">
					<input type="submit" class="btn btn-info updatevendor" value="Update"> -->

					<button type="button" class="btn btn-default " id="cancel-edit"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success update-vendor" >Update</button>
					
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>
<!-- Delete Modal HTML -->
<div id="deleteModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="<?php echo e(url('delete-vendor')); ?>" method="post" id="deleteVendor">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Delete Employee</h4>

					<input type="hidden" id="v_id" name="v_id">
					<button type="button" class="close" id="closebtndelete" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<p>Are you sure you want to delete  Records?</p>
					<p class="text-warning"><small>This action cannot be undone.</small></p>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-delete">
					<input type="submit" class="btn btn-danger" value="Delete">
				</div>
			</form>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>


$(document).ready(function() {

var count=0;
var myArray = [];
var arr=[];

fetchVendor();

function fetchVendor()
{
	$.ajax({
		type:"GET",
		url:"fetch-vendor",
		dataType:"json",
		success:function(response){
			
			// console.log(response.users);

			$('#t_body').html("");
			var pno='',fon='';
			$.each(response.vendors,function(key,item){
				
				if(item.phone!='')
				{
				pno=item.phone;
				// pno.replace(/[[\]]/g,'');
				fon=pno.replace(/[\[\]"]+/g,'<br>');
				}
				else{
					fon='';
				}
				// eval(pno);
				// alert(pno);
			$('#t_body').append('<tr>\
			<td>'+item.id+'</td>\
			<td>'+item.name+'</td>\
			<td>'+item.email+'</td>\
			<td>'+item.address+'</td>\
			<td>'+item.pincode+'</td>\
			<td>'+item.country+'</td>\
			<td>'+item.state+'</td>\
			<td>'+item.city+'</td>\
			<td>'+fon+'</td>\
			<td>'+item.billing_address+'</td>\
			<td> <button type="button" data-toggle="modal" class="edit" value="'+item.id+'" style="border:none; color:orange;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button></td>\
			<td> <button type="button" data-toggle="modal" class="delete" value="'+item.id+'" style="border:none; color:red;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></button></td>\
			</tr>');
			});

		}
	});
}


	$('#addModal').find('input').val("");
				
  $('#addPhoneNumber').click(function() {
    $('#modal-tbody').append('<tr><td><label>Phone Number</label></td><td><input type="text" name="phone[]" class="form-control" /></td>\
	<td> <button id="removePhoneNumber" class="form-control remove "style="width:40px;height:40px;text-align:center;background-color:red;color:white;" ><b>-</b></button></td></tr>');
  });


$(document).on("click",'.remove',function(){

$(this).closest('tr').remove(); 
});


	

$('#country').on('change', function() {
    
	var idCountry = this.value;
	

	$("#state").html('');
	$.ajax({
		type: "POST",
	  
		url:"/api/fetch-states/"+idCountry,
	  
		data: {
		  
			_token: '<?php echo e(csrf_token()); ?>'
		},
		dataType: 'json',
		success: function (result) {
	  
			$('#state').html('<option value="">-- Select State --</option>');
			$.each(result.states, function (key, value) {
				$("#state").append('<option value="' + value
					.id + '">' + value.name + '</option>');
			});
			// $('#cit').html('<option value="">-- Select City --</option>');
		}
	});

});


$('#state').on('change', function () {
              
			  var idState = this.value;
			  $("#city").html('');
			  $.ajax({
				  url:"/api/fetch-cities/"+idState,
				  type: "POST",
				  data: {
					  _token: '<?php echo e(csrf_token()); ?>'
				  },
				  success: function (res) {
					  $('#city').html('<option value="">-- Select City --</option>');
					  $.each(res.cities, function (key, value) {
						  $("#city").append('<option value="' + value
							  .id + '">' + value.name + '</option>');
						  //   $('#b_city').val();
					  });
				  }
			  });
		  });



$(document).on('click','.add-vendor',function(e){
		e.preventDefault();

	var myArray = $('input[name="phone[]"]').map(function() {
    return $(this).val();
  }).get();
//   console.log(myArray.toString());
	// alert($('#phone').val());
		var data={
			
			'name':$('#name').val(),
			'email':$('#email').val(),
			'address':$('#address').val(),
			'pincode':$('#pincode').val(),
			'country':$('#country').val(),
			'state':$('#state').val(),
			'city':$('#city').val(),
			'phone':JSON.stringify(myArray),
			// 'password_confirmation':$('#password1').val(),
			'bill_address':$('#bill_address').val(),
			// 'phone':$('#phone').val(),
			// 'image':$('#image').val(),
			
		}
		// console.log(data.phone);
		$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$.ajax({
			method:"POST",
			url:"/addvendor",
			data:data,
			dataType:"json",
			

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
				// console.log(response);
		
			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					
				});
			}
			else{
				// $('#addVendor')[0].reset();
				// alert(response);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchVendor();
				$('#addModal').modal('hide');

				
				$('#addModal').find('input').val("");
				
				
			}
			
			}
		});
		

	$('#closeBtn').click(function() {
	$('#success_message').html("");
	$(document).find('span.error-text').text('');
	$('#addModal').find('input').val("");
	$('#address').val("");
    $('#addModal').modal('hide');
	
	
});

$('#cancel-add').click(function() {
	$(document).find('span.error-text').text('');
	$('#addModal').find('input').val("");
	$('#address').val("");
	$('#addModal').modal('hide');
	
});


	});


	let isTableRowAdded = false;

	$(document).on('click','.edit',function(e){

	e.preventDefault();
	
    var vendor_id=$(this).val();
	//   alert(user_id);
	$('#editModal').modal('show');
	$("#vendorCountry").html('');
	$("#vendorState").html('');
	$("#vendorCity").html('');


	$.ajax({
		type:"GET",
		url:"/edit-vendor/"+vendor_id,
		
		success:function(response){
			arr='';
			arr=response.vendor.phone;
			
			if(arr!=''){
				
				fon=arr.replace(/[\[\]"]+/g,'');
				var nArray = fon.split(',');
				
				// alert($.type(nArray));
				$.each(nArray,function(index,val){
				
					// console.log(index,val);
				$('#modal-tbody_edit').append('<tr id="phoneno'+index+'"><td><label>Phone Number</label></td><td><input type="text" name="phone'+index+'" id="phone'+index+'"value="'+val+'" class="form-control" /></td>');
					count=index+1;
					isTableRowAdded = true;
					
				});
			
			$('#modal-tbody_edit').append('<td> <button id="addPhone1" class="form-control"style="width:40px;height:40px;text-align:center;background-color:#28a745;;color:white;" ><b>+</b></button></td>\
	</tr>');

			}

			else{
				
				

					count=0;
				}
			

			// console.log(response.vendor.country);
			$('#vendorName').val(response.vendor.name);
			$('#vendorEmail').val(response.vendor.email);
			$('#vendorAddress').val(response.vendor.address);
			$('#vendorPincode').val(response.vendor.pincode);
			// $('#vendorCountry').val(response.vendor.country);
			// $('#vendorState').val(response.vendor.state);
			// $('#vendorCity').val(response.vendor.city);
			$('#billAddress').val(response.vendor.billing_address);

			$("#vendorCountry").html('<option>' + response.vendor.country + '</option>');
			$("#vendorState").html('<option>' + response.vendor.state + '</option>');
			$("#vendorCity").html('<option>' + response.vendor.city + '</option>');
			$.each(response.data.countries, function (key, value) {
                            $("#vendorCountry").append('<option value="' + value.id + '">' + value.name + '</option>');
                        });
			// $.each(response.data1.states, function (key, value) {
            //                 $("#vendorState").append('<option value="' + value.id + '">' + value.name + '</option>');
            //             });			
			// $.each(response.data2.cities, function (key, value) {
            //                 $("#vendorCity").append('<option value="' + value.id + '">' + value.name + '</option>');
            //             });
		
			// $("#avatar").html(
            //   `<img src="${response.user.image}" width="100" class="img-fluid img-thumbnail">`);
			$('#vendor_id').val(vendor_id);

		}
	});
   });

   $('#closebtn1').click(function() {
    $('#editModal').modal('hide');
	$('#editModal').find('input').val("");
	
	$(document).find('span.error-text').text('');
	location.reload(true);
    alert('Reloading Page');
});
// btn btn-default
$('#cancel-edit').click(function() {

    $('#editModal').modal('hide');
	$('#editModal').find('input').val("");
});






$(document).on('click','.delete',function(){
		// var user_id=$(this).val();
		var vendor_id=$(this).val();
		$('#deleteModal').modal('show');
		$('#v_id').val(vendor_id);
		// alert(vendor_id);
		


	});

	$('#cancel-delete').click(function() {
    $('#deleteModal').modal('hide');
});
	$('#closebtndelete').click(function() {
    $('#deleteModal').modal('hide');
	$('#deleteModal').find('input').val("");
});



$('#closeBtn1').click(function() {
	$('#success_message').html("");
	$(document).find('span.error-text').text('');
	$('#editModal').find('input').val("");
	$('#vendorAddress').val("");
    $('#editModal').modal('hide');
	
	
});

$('#cancel-edit').click(function() {
	$(document).find('span.error-text').text('');
	$('#editModal').find('input').val("");
	$('#vendorAddress').val("");
	$('#editModal').modal('hide');
	
});

$('#vendorCountry').on('change', function() {
    
	var idCountry = this.value;
	

	$("#vendorState").html('');
	$.ajax({
		type: "POST",
	  
		url:"/api/fetch-states/"+idCountry,
	  
		data: {
		  
			_token: '<?php echo e(csrf_token()); ?>'
		},
		dataType: 'json',
		success: function (result) {
	  
			$('#vendorState').html('<option value="">-- Select State --</option>');
			$.each(result.states, function (key, value) {
				$("#vendorState").append('<option value="' + value
					.id + '">' + value.name + '</option>');
			});
			// $('#cit').html('<option value="">-- Select City --</option>');
		}
	});

});


$('#vendorState').on('change', function () {
              
			  var idState = this.value;
			  $("#vendorCity").html('');
			  $.ajax({
				  url:"/api/fetch-cities/"+idState,
				  type: "POST",
				  data: {
					  _token: '<?php echo e(csrf_token()); ?>'
				  },
				  success: function (res) {
					  $('#vendorCity').html('<option value="">-- Select City --</option>');
					  $.each(res.cities, function (key, value) {
						  $("#vendorCity").append('<option value="' + value
							  .id + '">' + value.name + '</option>');
						  //   $('#b_city').val();
					  });
				  }
			  });
		  });



		  $(document).on('click', '.update-vendor', function(e) {
       e.preventDefault();
	    var myArray = [];
	
//   }).get();
// console.log(count);
for(i=0;i<count;i++)
{
	myArray.push($('#phone'+i+'').val());
}
// console.log(JSON.stringify(myArray));
	
	   var data={


			'vendorName':$('#vendorName').val(),
			'vendorEmail':$('#vendorEmail').val(),
			'vendorAddress':$('#vendorAddress').val(),
			'vendorPincode':$('#vendorPincode').val(),
			'vendorCountry':$('#vendorCountry').val(),
			'vendorState':$('#vendorState').val(),
			'vendorCity':$('#vendorCity').val(),
			'billAddress':$('#billAddress').val(),
			'vendor_id':$('#vendor_id').val(),
			'phone':JSON.stringify(myArray)
		}
	

		$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
	$.ajax({
			type:"POST",
			url:"/update-vendor",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			if(response.status==400){
			
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
				
				})
			}
			else{
			// alert(response.cdata.name);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchVendor();
				$('#editModal').modal('hide');
				$('#editModal').find('input').val("");

			
				
			}
			
			}
		});

});





	  
});


  

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sample\vendor_management\resources\views/admin/view_all_Vendor.blade.php ENDPATH**/ ?>