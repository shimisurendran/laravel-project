
<?php $__env->startSection('content'); ?>



<div class="container py-5" style="text-align:center">

<div class="row">

<div class="col-md-12">
<!-- <div id="success_message"></div> -->


   
<!-- <div class="card" > -->



            <!-- <div class="card-body"> -->

<table class="table">
  <thead>
 <tr>
 <th colspan="4"><h4 >Manage <b>Category</b></h4>

</th>
	<th colspan="3">
         <a href="#addModal" class="" data-toggle="modal" > <span style="background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New Branch</span></a> 
    
    <!-- <button type="button" data-toggle="modal" class="addcategory" value="" style="border:none; background-color:#4154f1; width:200px;height:50px; color:white;padding: 15px;
    border-radius: 5px;dislpay:inline-block;" ><i class="material-icons">&#xE147;</i>Add New Category</button> -->
					
</th></tr>  
    <tr>
	<th scope="col">Serial No</th>
      <th scope="col">CATEGORY NAME</th>
      <th scope="col">CATEGORY TYPE</th>
      <th scope="col">BRANCH NAME</th>
	  <!-- <th scope="col">IMAGE</th> -->
      <th scope="col" colspan="2">ACTIONS</th>
    </tr>
  </thead>
  <tbody>
  
    
  </tbody>
</table>

</div>
<!-- </div> -->
<!-- </div> -->
</div></div>

<!-- Add Modal HTML -->
<div id="addModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<!-- <form action="<?php echo e(url('add_category')); ?>" method="post"  enctype="multipart/form-data"> -->
            <?php echo csrf_field(); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Add New Category</h4>
					<button type="button" class="close" id="closeBtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
				<div class="form-group">
						<label>Category Name</label>
						<input type="text" class="form-control" required  name="name" id="name">
						<span class="text-danger error-text name_error" style="position:fixed"></span>
					</div>
					<div class="form-group">
						<label>Category Type</label>
						<select   class="form-control " required name="type" id="type">
                                <option value="">-Select Category Type-</option>
                                <option>Hardware</option>
                         
                                <option>Software</option>
                         
                        </select>
						<span class="text-danger error-text type_error" style="position:fixed"></span>
                        
					</div>

                    <div class="form-group">
						<label>Branch Name</label>
						<select   class="form-control " required name="branchname" id="branchname">
                                <option value="">-Select Branch Name-</option>
                                <?php $__currentLoopData = $data['branches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data->id); ?>">
                                <?php echo e($data->b_name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </select>
						<span class="text-danger error-text branchname_error" style="position:fixed"></span>
                        
					</div>
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-add">
					<input type="submit" class="btn btn-success" value="Add"> -->
					<button type="button" class="btn btn-default " id="cancel-add"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success add-category" >save</button>
				</div>
				</div>
			<!-- </form> -->
		</div>
	</div>
</div>


<!-- Edit Modal HTML -->
<div id="editModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
		<!-- <form id="updateCategory" action="<?php echo e(url('update-category')); ?>" method="post"  enctype="multipart/form-data">	<?php echo csrf_field(); ?> -->
			
				<input type="hidden" id="cid" name="cid" >
				<div class="modal-header">						
					<h4 class="modal-title">Edit Category Details</h4>
					<button type="button" class="close" id="closebtn" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">	
				
				<div class="form-group">
						<label>Category Name</label>
						<input type="text" class="form-control" required name="categoryname" id="categoryname">
						<span class="text-danger error-text categoryname_error" style="position:fixed"></span>
					</div>
				
                    <div class="form-group">
						<label>Category Type</label>

                            <select class="form-control " required name="categorytype" id="categorytype">
                          
                        </select>
						<span class="text-danger error-text categorytype_error" style="position:fixed"></span>
					</div>
                    <div class="form-group">
						<label>Branch Name</label>
						
                            <select class="form-control " required name="branchName" id="branchName">
                         
                        </select>
						<span class="text-danger error-text branchName_error" style="position:fixed"></span>
					</div>				
				</div>
				<div class="modal-footer">
					<!-- <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-edit">
					<input type="submit" class="btn btn-info" value="Update">
					 -->

					 <button type="button" class="btn btn-default " id="cancel-edit"  data-dismiss="modal" value="Cancel">Cancel</button>
					<button type="button" class="btn btn-success update-category" >Update</button>
			<!-- </form> -->
		</div>
	</div>
</div>
<!-- Delete Modal HTML -->
<div id="deleteModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="<?php echo e(url('delete-category')); ?>" method="post" id="deleteCategory">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
				<div class="modal-header">						
					<h4 class="modal-title">Delete Category</h4>

					<input type="hidden" id="catid" name="catid">
					<button type="button" class="close" id="closebtnedit" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">					
					<p>Are you sure you want to delete  Records?</p>
					<p class="text-warning"><small>This action cannot be undone.</small></p>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel" id="cancel-delete">
					<input type="submit" class="btn btn-danger" value="Delete">
				</div>
			</form>
		</div>
	</div>
</div>


</div></div></div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>




//add category

$(document).ready(function(){


	$('#cancel-add').click(function() {
    $('#addModal').modal('hide');
});


$('#cancel-edit').click(function() {
    $('#editModal').modal('hide');
});


$('#cancel-delete').click(function() {
    $('#deleteModal').modal('hide');
});



	$(document).on('click','.addcategory',function(){
        $('#addModal').modal('show');
    
      
    });
    
  
     $('#closeBtn').click(function() {
    $('#addModal').modal('hide');
});
// });


//edit category


// $(document).ready(function(){
   $(document).on('click','.edit',function(){
      var cid=$(this).val();
    //  alert(cid);
	$('#editModal').modal('show');
	

	$.ajax({
		type:"GET",
		url:"/edit-category/"+cid,
		
		success:function(response){
            // alert(response.status);
			// console.log(response.data.bname);
			$('#categoryname').val(response.category.category_name);
			$('#categorytype').val(response.category.category_type);
			
			$("#categorytype").html('');
            $("#branchName").html('');
		
			$("#categorytype").html('<option>Hardware</option> <option>Software</option>');
			
			$.each(response.data.bname, function (key, value) {
                            $("#branchName").append('<option value="' + value.id + '">' + value.b_name + '</option>');
                        });


			$('#cid').val(cid);

		}
	});


	



// });
  

   $('#closebtn').click(function() {
    $('#editModal').modal('hide');
});

});


//delete category


// $(document).ready(function(){
	$(document).on('click','.delete',function(){
		var cid=$(this).val();
		// alert(cid);
		$('#deleteModal').modal('show');
		$('#catid').val(cid);
	
	});

	
	$('#closebtnedit').click(function() {
    $('#deleteModal').modal('hide');
});

// });









	
   $('#closeBtn').click(function() {
	$(document).find('span.error-text').text('');

    $('#addModal').modal('hide');
	
	
});




fetchCategory();

function fetchCategory()
{
	$.ajax({
		type:"GET",
		url:"fetch-category",
		dataType:"json",
		success:function(response){
			// console.log(response.users);
			$('tbody').html("");
			$.each(response.categories,function(key,item){
			$('tbody').append('<tr>\
			<td>'+item.id+'</td>\
			<td>'+item.category_name+'</td>\
			<td>'+item.category_type+'</td>\
			<td>'+item.b_name+'</td>\
			<td> <button type="button" data-toggle="modal" class="edit" value="'+item.id+'" style="border:none; color:orange;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></button></td>\
			<td> <button type="button" data-toggle="modal" class="delete" value="'+item.id+'" style="border:none; color:red;background-color:white;" ><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></button></td>\
			</tr>');
			});

		}
	});
}







$(document).on('click','.add-category',function(e){
		e.preventDefault();
		
		
		console.log($('#name').val());
		var data={
			
			'name':$('#name').val(),
			'type':$('#type').val(),
			'branchname':$('#branchname').val(),
		
		}
		$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$.ajax({
			type:"POST",
			url:"/add_category",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
					
				})
			}
			else{
				// $('#addUser')[0].reset();
				// alert(response.user);
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchCategory();
				$('#addModal').modal('hide');

				
				$('#addModal').find('input').val("");
				
				
			}
			
			}
		});
		

		
	});
	$('#closeBtn').click(function() {
    $('#addModal').modal('hide');

});





$(document).on('click', '.update-category', function(e) {
       e.preventDefault();
	
	   var data={
			'categoryname':$('#categoryname').val(),
			'categorytype':$('#categorytype').val(),
			'branchName':$('#branchName').val(),
			'cid':$('#cid').val()
			
		}

		$.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
	$.ajax({
			type:"POST",
			url:"/update-category",
			data:data,
			dataType:"json",

			beforeSend:function(){
			$(document).find('span.error-text').text('');
			},
			success:function(response){
			
			

			if(response.status==400){
				
				
				$.each(response.errors,function(key,err_values){
					
					$('span.'+key+'_error').text(err_values[0])
				
				})
			}
			else{
			
				
				$('#success_message').html("");
				$('#success_message').addClass('alert alert-success');

				$('#success_message').text(response.message);
				fetchCategory();
				$('#editModal').modal('hide');
				$('#editModal').find('input').val("");

			
				
			}
			
			}
		});

});


});



   </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\sample\vendor_management\resources\views/admin/view_all_categories.blade.php ENDPATH**/ ?>