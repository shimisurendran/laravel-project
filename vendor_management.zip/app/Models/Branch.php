<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    use HasFactory;

    protected $fillable = [
        'b_name',
        'b_email',
        'b_address',
        'b_phone',
        'b_country',
        'b_state',
        'b_city',

        
    ];



}
