<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Branch;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use App\Models\Category;
use App\Models\Vendor;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Mail;
use App\Mail\VendorMail;
// use Session;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function getUsers(){
 
        // $users = User::orderby('id','asc')->select('*')->get(); 
         
        // Fetch all records
        // $users = User::latest()->paginate(5); 
        $users = User::orderby('id','asc')->select('*')->latest()->get(); 
       
        return view('admin/view_all_user',  compact('users'));
        // return view('admin/view_all_user',  compact('users'))->with('i',(request()->input('page',1)-1)*5);
       
      }

      public function fetchUser(){
 
        $users = User::orderby('id','asc')->select('*')->get(); 
       
        return response()->json([
            'users'=>$users
        ]);
     
      }

      public function getUserbyid(Request $request){
 
        $userid = $request->userid;
   
        $users = Users::select('*')->where('id', $userid)->get();
   
        // Fetch all records
        $response['data'] = $users;
   
        return view("admin/view_all_user")->json($response);
     }

     public function addUser(Request $request){
      
        
        $validator=Validator::make($request->all(),[
            'name'          =>  'required',
            'email'         =>  'required|regex:/(.+)@(.+)\.(.+)/i',
            'address'       =>  'required',
            'phone'         =>  'required',
            'role'          => 'required',
            'password' => 'required|confirmed|min:6',
            'password_confirmation' => 'required']);


$user = new User;
  if($validator->fails())
  {
    return response()->json([
        'status'=>400,
        'errors'=>$validator->messages(),
    ]);

    // return back()->withErrors($validator->errors())->withInput();
  }
      else{
        if($request->file('image')){
        dd($request->file('image'));
        
        $file=$request->file('image');
        $fileName=time().'_'.$file->getClientOriginalName();
        // echo "<pre>";print_r($fileName);die;
        // echo "<pre>";print_r($fileName);die;
        $file->move('images',$fileName);
        $user->image = $fileName;
        }
       
    else{
        $fileName="";
    }
       
        $user->name = $request->name;
        $user->role = $request->role;
        $user->email = $request->email;
        $user->address = $request->address;
        $user->phone = $request->phone;
        $user->password=Hash::make($request->password);
        $user->save();
    
        return response()->json([
            'status'=>200,
            'message'=>'Added successfully',
            'user'=>$user->id
        ]);
        // return redirect()->back()->with('success', 'User Added successfully.');
      }

        // $mailData = [
        //     'title' => 'Mail from shimi',
        //     'body' => 'This is for testing email using smtp.',
        //     "username"=>$request->email,
        //     "password"=>$request->password
        // ];
         
        // Mail::to('livines979@ngopy.com')->send(new VendorMail($mailData));
           
        // dd("Email is sent successfully.");

        // return redirect()->back()->with('success', 'User Added successfully.');
 
    }


    public function edit($id)
    {
      
        $user=User::find($id);
        // dd($user);
        return response()->json([
            'status'=>200,
            'user'=>$user,
        ]);
    }

    public function update(Request $request)
    {
		$user = User::find($request->user_id);
       
        $validator=Validator::make($request->all(),[
            
                'username'          =>  'required',
                'user_address'       =>  'required',
                'phoneNumber'         =>  'required']);
        if($validator->fails())
                {
                  return response()->json([
                      'status'=>400,
                      'errors'=>$validator->messages(),
                  ]);
                }
        else{

        $user->name=$request->username;
        $user->address=$request->user_address;
        $user->phone=$request->phoneNumber;
        $user->save();

            return response()->json([
                'status'=>200,
                'message'=>'Updated successfully',
                         ]);
        }

 
    }

    public function delete(Request $request)
    {
        
        // DB::delete('DELETE from users WHERE id=?',[$id]);
        // $user = User::where('id', $id)->firstorfail()->delete();
        $id=$request->userid;
        $user=User::find($id);
        $user->delete();

        return redirect()->back()->with('success', 'User deleted successfully.');
    }



    public function getBranch(){
 
        $branches = Branch::orderby('id','asc')->select('*')->get(); 
        $data['countries'] = Country::get(["name", "id"]);
        // Fetch all records
        //  echo "<pre>";print_r($data['countries']);die;
        return view('admin/view_all_branches',  compact('branches','data'));
       
      }

      public function fetchState(Request $request,$idCountry)
      {
        // echo "<pre>";print_r($idCountry);die;
          $data['states'] = State::where("country_id", $request->idCountry)
                                  ->get(["name", "id"]);
                                //   echo "<pre>";print_r($data['states']);die;
    
          return response()->json($data);
      }

      public function fetchBranch(){
 
        $branches = Branch::orderby('id','asc')->select('*')->get(); 
       
        return response()->json([
            'branches'=>$branches
        ]);
        // return view('admin/view_all_user'  compact('users'))->with('i',(request()->input('page',1)-1)*5);
   
      }


      public function fetchCity(Request $request,$idState)
      {
          $data['cities'] = City::where("state_id", $request->idState)
                                      ->get(["name", "id"]);
                                        
          return response()->json($data);
      }



      public function addBranch(Request $request)
      {
       
        $validator=Validator::make($request->all(),[
            
                        'name'          =>  'required',
                        'email'         =>  'required|email',
                        'address'       =>  'required',
                        'phone'         =>  'required',
                        'country'       =>   'required',
                        'state'         =>   'required',
                        'city'          =>   'required',
            
        ]);
      
        
      
        if($validator->fails())
                {
                  return response()->json([
                      'status'=>400,
                      'errors'=>$validator->messages(),
                  ]);
                }
        else{
 $coid= $request->country;
 $sid= $request->state;
 $cid= $request->city;

$country = Country::find($coid);
$state = State::find($sid);
$city=City::find($cid);
// $city = DB::select('select name from cities where id = ?', [$cid]);

//   echo "<pre>";print_r($city1->name);die;
       

        $branch = new Branch;
        $branch->b_name = $request->name;
        $branch->b_email = $request->email;
        $branch->b_address = $request->address;
        $branch->b_phone = $request->phone;
        $branch->b_country = $country->name;
        $branch->b_state = $state->name;
        $branch->b_city = $city->name;
       
        $branch->save();

        return response()->json([
            'status'=>200,
            'message'=>'Inserted successfully',
                     ]);

        }

        // return redirect()->back()->with('success', 'Branch Added successfully.');
 
    }

    public function editBranch($branch_id)
    {
        
        $data['countries'] = Country::get(["name", "id"]);
        //  echo "<pre>";print_r($data['countries']);die;
       
        $branch=Branch::find($branch_id);

        return response()->json([
            'status'=>200,
            'data'=>$data,
            'branch'=>$branch,
        ]);
    }

    public function updateBranch(Request $request)
    {
        // echo "<pre>";print_r($request->cit);die;

        // $branch = Branch::find($request->branch_id);
       
        $validator=Validator::make($request->all(),[
            
                // 'coun'                 =>  'required',
                // 'stat'                 =>  'required',
                // 'cit'                  =>  'required',
                'branch_name'          =>  'required',
                'branch_email'         =>  'required',
                'branch_address'       =>  'required',
                'phoneNumber'          =>  'required']);
        if($validator->fails())
                {
                  return response()->json([
                      'status'=>400,
                      'errors'=>$validator->messages(),
                  ]);
                }
        else{

        // $coid= $request->coun;
       
        // $sid= $request->stat;
        // $cid= $request->cit;
// $country = Country::find($coid);
// $country=DB::table('countries')->where('name',$coid)->first();
// dd($country);

// $state = State::find($sid);
// $city=City::find($cid);
        
	     $branch = Branch::find($request->branch_id);
      $branch->b_address= $request->branch_address;
      $branch->b_phone=$request->phoneNumber;
      $branch->b_name=$request->branch_name;
      $branch->b_email=$request->branch_email;
      // $branch->b_city=$city->name;
      $branch->save();

		

        return response()->json([
            'status'=>200,
            'message'=>'updated successfully',
                     ]);

         }
       
    }


    public function deleteBranch(Request $request)
    {
        
     
        $bid=$request->branchid;
        $branch=Branch::find($bid);
        $branch->delete();

        return redirect()->back()->with('success', 'branch deleted successfully.');
    }


    public function getCategory(){

        $data['branches'] = Branch::get(["b_name","id"]);
        
 
       $categories=DB::table('branches')
       ->join('categories','branches.id','=','categories.branch_id')
       ->select('categories.*','branches.b_name')->get();
        return view('admin/view_all_categories',  compact('categories','data'));
       
      }
      public function fetchCategory(){
        $data['branches'] = Branch::get(["b_name","id"]);
       
 
        $categories=DB::table('branches')
        ->join('categories','branches.id','=','categories.branch_id')
        ->select('categories.*','branches.b_name')->get();
        // dd($categories);
 
        // $categories = Category::orderby('id','asc')->select('*')->get(); 
       
        return response()->json([
            'categories'=>$categories
        ]);
     
      }

      
      public function addCategory(Request $request)
      {
        $validator=Validator::make($request->all(),[
            
          'name'        => 'required',
          'type'       =>  'required',
          'branchname' =>  'required',
        

]);



if($validator->fails())
  {
    return response()->json([
        'status'=>400,
        'errors'=>$validator->messages(),
    ]);
  }
else{
      
        
     

        $category = new Category;
        $category->category_name = $request->name;
        $category->category_type = $request->type;
        $category->branch_id = $request->branchname;
       
       
        $category->save();

        // return redirect()->back()->with('success', 'Category Added successfully.');
        return response()->json([
          'status'=>200,
          'message'=>'Inserted successfully',
                   ]);
 
    }

  }
    
    public function editCategory($cid)
    {
        
       
        $data['bname'] = Branch::select('b_name','id')->distinct()->get();
      
        $category=Category::find($cid);

        return response()->json([
            'status'=>200,
            'data'=>$data,
            'category'=>$category,
        ]);
    }



    public function updateCategory(Request $request)
    {
       

       

         $cate = Category::find($request->cid);

         $validator=Validator::make($request->all(),[
            
          'categoryname'          =>  'required',
          'categorytype'       =>  'required',
          'branchName'         =>  'required']);
  if($validator->fails())
          {
            return response()->json([
                'status'=>400,
                'errors'=>$validator->messages(),
            ]);
          }
  else{

		$categoryData = ['category_name' => $request->categoryname, 'category_type' => $request->categorytype,'branch_id'=>$request->branchName];
        // echo "<pre>";print_r($categoryData);die;
		$cate->update($categoryData);
		// return redirect()->back()->with('success', 'Category Updated successfully.');

    
    return response()->json([
      'status'=>200,
      'message'=>'updated successfully',
               ]);

  }
    }

    public function deleteCategory(Request $request)
    {
        
     
        $cid=$request->catid;
        // echo "<pre>";print_r($cid);die;
        $category=Category::find($cid);
        $category->delete();

        return redirect()->back()->with('success', 'Category deleted successfully.');
    }




    public function getVendor(){
        // $vendorsdtls = Vendor::orderby('id','asc')->select('*')->get(); 

       $vendors=DB::table('users')->select('name')->where('role','Vendor')->get();
    //    foreach($vendors as $vendor){
    //     echo $vendor->name."<br>";
    //    }
    $data['countries'] = Country::get(["name", "id"]);
        return view('admin/view_all_Vendor',compact('vendors','data'));
       
      }
      public function sendMail()
      {
          $mailData = [
              'title' => 'Mail from ItSolutionStuff.com',
              'body' => 'This is for testing email using smtp.'
          ];
           
          Mail::to('shimivng@gmail.com')->send(new VendorMail($mailData));
             
        //   dd("Email is sent successfully.");
      }
      


      public function addVendor(Request $request){
      
     
        // $pn=array($request->phone);
      
       $pn=json_encode($request->phone);
     
        // return response()->json([
        //             'success'=>'success',
        //             'pn'=>$pn
                   
        //         ]);
            
        $validator=Validator::make($request->all(),[
            'name'          =>  'required',
            'email'         =>  'required|regex:/(.+)@(.+)\.(.+)/i',
            'address'       =>  'required',
            'pincode'       => 'required',
            'country'       => 'required',
            'state'         => 'required',
            'city'          => 'required',
            'bill_address'  => 'required',
          ]);


$vendor = new Vendor;
  if($validator->fails())
  {
    return response()->json([
        'status'=>400,
        'errors'=>$validator->messages(),
    ]);

   
  }
      else{


 $coid= $request->country;
 $sid= $request->state;
 $cid= $request->city;

$country = Country::find($coid);
$state = State::find($sid);
$city=City::find($cid);
     
        $vendor->name = $request->name;
        $vendor->address = $request->address;
        $vendor->email = $request->email;
        $vendor->billing_address = $request->bill_address;
        $vendor->pincode = $request->pincode;
        $vendor->country = $country->name;
        $vendor->state = $state->name;
        $vendor->city = $city->name;
        $vendor->phone =stripslashes($pn);
        $vendor->save();
        
        return response()->json([
            'status'=>200,
            'message'=>'Added successfully',
            // 'vendor'=>$vendor->id
        ]);
         }

       
    }


    public function fetchVendor(){
 
     
      // dd($cdata);

        $vendors = Vendor::orderby('id','asc')->select('*')->get(); 
// foreach($vendors as $vendor )
// {
//   $cdata=DB::table('countries')->join('states','countries.id','=','states.country_id')
//   ->join('cities','states.id','=','cities.state_id')
//   ->select('countries.name')->where('countries.id','=',$vendor->country)
//   ->get()->all();
  

// }
// dd($cdata);
       
        return response()->json([
            'vendors'=>$vendors
        ]);
        // return view('admin/view_all_user'  compact('users'))->with('i',(request()->input('page',1)-1)*5);
   
      }



      public function editVendor($vendor_id)
      {
          
        $data['countries'] = Country::get(["name", "id"]);
      //  $data['countries'] = DB::;
        // $data1['states'] = State::get(["name", "id"]);
        // $data2['cities'] = City::get(["name", "id"]);
          
        
          $vendor=Vendor::find($vendor_id);
          // dd($vendor->country);
          return response()->json([
              'status'=>200,
              'vendor'=>$vendor,
              'data'=>$data,
             
          ]);
      }
  

      public function updateVendor(Request $request)
      {
        // echo "<pre>";print_r($request->vendorCountry);die;
        dd($request->phone);

           $vendor = Vendor::find($request->vendor_id);
  
           $validator=Validator::make($request->all(),[
              
            'vendorName'        =>  'required',
            'vendorEmail'       =>  'required',
            'vendorAddress'     =>  'required',
            'vendorPincode'     =>  'required',
            'vendorCountry'     =>  'required',
            'vendorState'       =>  'required',
            'vendorCity'        =>  'required',
            'billAddress'       =>  'required',
         
          
          
          ]);
    if($validator->fails())
            {
              return response()->json([
                  'status'=>400,
                  'errors'=>$validator->messages(),
              ]);
            }
    else{
    
      $pn=json_encode($request->phone);
      
      $cid=$request->vendorCountry;
      $sid=$request->vendorState;
      $citid=$request->vendorCity;

    

$country = Country::find($cid);
$state = State::find($sid);
$city=City::find($citid);
      // dd($request->vendorCountry);
  // $cdata=DB::table('countries')->join('states','countries.id','=','states.country_id')
  // ->join('cities','states.id','=','cities.state_id')
  // ->where('states.id','=',$sid)
  // ->where('countries.id','=',$citid)
  // ->get();
  // dd($cdata);

  
      $vendorData = ['name' => $request->vendorName, 'email' => $request->vendorEmail,'address' => $request->vendorAddress,'country' => $country->name,
      'state'=>$state->name,'city' => $city->name,'pincode' => $request->vendorPincode,'billing_address' => $request->billAddress,'phone'=>stripslashes($pn)];
          // echo "<pre>";print_r($categoryData);die;
      $vendor->update($vendorData);
      // return redirect()->back()->with('success', 'Category Updated successfully.');
  
      
      return response()->json([
        'status'=>200,
        'message'=>'updated successfully',
      
                 ]);
  
    }
      
      }

      public function deleteVendor(Request $request)
      {
          // dd($request->vendor_id);
       
          $vendor_id=$request->v_id;
          // echo "<pre>";print_r($cid);die;
          $vendor=Vendor::find($vendor_id);
          $vendor->delete();
  
          return redirect()->back()->with('success', 'vendor deleted successfully.');
      }
  
  
  


     }

    




